export default async function handler(req, res) {
  const key = process.env.PULSESCORE_API_KEY;
  if (!key) {
    return res.status(500).json({ error: 'Missing PULSESCORE_API_KEY environment variable.' });
  }

  const url = 'https://api.pulsescore.net/api/v3/bet365/live-events?sport=tennis';

  try {
    const upstream = await fetch(url, {
      headers: {
        'X-Secret': key,
        'Accept': 'application/json'
      },
      cache: 'no-store'
    });

    if (!upstream.ok) {
      const text = await upstream.text();
      return res.status(upstream.status).json({
        error: 'PulseScore request failed',
        detail: text.slice(0, 500)
      });
    }

    const data = await upstream.json();
    const events = Array.isArray(data) ? data : (data.events || data.data || []);

    const target = events.find(item => {
      const home = (item.home || '').toLowerCase();
      const away = (item.away || '').toLowerCase();
      const league = (item.league || '').toLowerCase();
      return league.includes('us open') &&
        ((home.includes('gauff') && away.includes('rybakina')) ||
         (home.includes('rybakina') && away.includes('gauff')));
    });

    if (!target) {
      return res.status(200).json({
        updatedAt: new Date().toISOString(),
        match: null,
        message: 'Gauff-Rybakina is not currently present in the US Open live feed.'
      });
    }

    const home = (target.home || '').toLowerCase();
    const away = (target.away || '').toLowerCase();
    const isGauffHome = home.includes('gauff');

    const score = target.score || {};
    const statistics = target.statistics || {};
    const setsHome = statistics?.sets?.home || [];
    const setsAway = statistics?.sets?.away || [];

    const scoreValue = playerIsHome => {
      const raw = playerIsHome ? score.home : score.away;
      return raw ?? null;
    };

    const info = score.info || '';
    const period = target.matchClock?.period || '';
    const live = target.live === 1 || target.live === true;

    return res.status(200).json({
      updatedAt: new Date().toISOString(),
      match: {
        eventId: target.eventId || target.fi || null,
        status: live ? 'live' : 'ended',
        statusLabel: live ? 'LIVE' : 'FINAL',
        gameState: info || null,
        periodScores: {
          home: setsHome,
          away: setsAway
        },
        currentSet: period || null,
        venue: 'Arthur Ashe Stadium',
        gauff: {
          score: scoreValue(isGauffHome),
          name: isGauffHome ? target.home : target.away,
          sets: isGauffHome ? setsHome : setsAway
        },
        rybakina: {
          score: scoreValue(!isGauffHome),
          name: isGauffHome ? target.away : target.home,
          sets: isGauffHome ? setsAway : setsHome
        },
        serve: statistics.homeServe === true
          ? (isGauffHome ? 'Gauff' : 'Rybakina')
          : (isGauffHome ? 'Rybakina' : 'Gauff')
      }
    });
  } catch (error) {
    return res.status(500).json({
      error: 'Unable to retrieve live score.',
      detail: error.message
    });
  }
}
